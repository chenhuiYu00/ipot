#ifndef _UBOOST_H_
#define _UBOOST_H_

void uboost();

#endif
