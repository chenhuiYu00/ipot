# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for roscpp_generate_messages_py.
