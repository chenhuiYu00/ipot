#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/yuchen/usetest/ROS/src/smb_highlevel_controller/cmake-build-debug/devel:$CMAKE_PREFIX_PATH"
export LD_LIBRARY_PATH="/home/yuchen/usetest/ROS/src/smb_highlevel_controller/cmake-build-debug/devel/lib:$LD_LIBRARY_PATH"
export PKG_CONFIG_PATH="/home/yuchen/usetest/ROS/src/smb_highlevel_controller/cmake-build-debug/devel/lib/pkgconfig:$PKG_CONFIG_PATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/yuchen/usetest/ROS/src/smb_highlevel_controller/cmake-build-debug/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH='/home/yuchen/usetest/ROS/src/smb_highlevel_controller:/home/yuchen/usetest/ROS/src/learning_communication:/home/yuchen/usetest/ROS/src/pointcloud_to_laserscan:/home/yuchen/usetest/ROS/src/smb_common_v2/smb_control:/home/yuchen/usetest/ROS/src/smb_common_v2/smb_description:/home/yuchen/usetest/ROS/src/smb_common_v2/smb_gazebo:/home/yuchen/usetest/ROS/src/smb_highlevel_controller:/home/yuchen/usetest/ROS/src/teleop_twist_keyboard:/home/yuchen/usetest/ROS/src/test:/home/yuchen/usetest/ROS/src/test2:/home/yuchen/usetest/ROS/src/two_point:/home/yuchen/usetest/ROS/src/velodyne-master/velodyne:/home/yuchen/usetest/ROS/src/velodyne_gazebo_plugins:/home/yuchen/usetest/ROS/src/velodyne-master/velodyne_laserscan:/home/yuchen/usetest/ROS/src/velodyne-master/velodyne_msgs:/home/yuchen/usetest/ROS/src/velodyne-master/velodyne_driver:/home/yuchen/usetest/ROS/src/velodyne-master/velodyne_pcl:/home/yuchen/usetest/ROS/src/velodyne-master/velodyne_pointcloud:/opt/ros/noetic/share'